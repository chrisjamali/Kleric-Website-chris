import React from 'react'

const DownloadButton = () => {
  return (
    <div>
      <a href='https://github.com/oslabs-beta/Kleric' target ='blank_'>
      <button className='download'> Download </button>
      </a>

    </div>
  );
}

export default DownloadButton